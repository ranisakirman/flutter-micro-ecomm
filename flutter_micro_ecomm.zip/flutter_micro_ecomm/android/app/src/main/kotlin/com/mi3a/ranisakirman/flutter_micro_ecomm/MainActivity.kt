package com.mi3a.ranisakirman.flutter_micro_ecomm

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
